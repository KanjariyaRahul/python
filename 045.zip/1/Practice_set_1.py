# 1) Write a program that prints your name and your college name.

# Assign values to variables
my_name = "Rahul Kanjariya"
college_name = "Atmiya University University"

# Print name and college name
print("My name is:", my_name)
print("My college is:", college_name)

---------------------------------------------------------------

# 2) Write a program that prints your address with name, all in new lines


my_name = "Rahul kanjariya"
my_address = "Ram Mandir Street,\nJunanagna,\nJamnagar,\nGujarat"

# Print name and address on separate lines
print("Name:", my_name)
print("Address:")
print(my_address)


---------------------------------------------------------------

#3) Write a program that accept two numbers and perform all basic mathematical operations.


num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number:"))


sum = num1 + num2
print("\nThe Sum of two number :", sum)  
subtraction = num1 - num2
print("\nThe subtraction of two number :", subtraction)
multiplication = num1 * num2
print("\nThe multiplication of two number :", multiplication)
division = num1 / num2
print("\nThe Division of two number :", division)



---------------------------------------------------------------

#4) Write a program to calculate simple interest.


p = float(input("Enter the principal amount: "))

t = float(input("Enter the time period : "))

r = float(input("Enter the rate of interest : "))


simple_interest = (p * t * r) / 100

print ("-------------------------- \n")
print("Simple Interest:", simple_interest)

--------------------------------------------------------------

# 5)Write a program to calculate 10% bonus of salary.

salary = float(input("Enter the salary: "))


bonus = (10* salary)/100

new_salary = salary + bonus

print("--------------------")
print("Original Salary:", salary)
print("\nBonus (10%):", bonus)
print("\nNew Salary:", new_salary)

---------------------------------------------------------------
# 6) Write a program to convert KM into Meter.


km = float(input("Enter distance in kilometer: "))

m = km * 1000;
print("--------------------------------------\n")
print("%0.2f Kilometer = %0.2f Meter" %(km,m))

---------------------------------------------------------------

#7) The distance between two cities is input through keyboard. 
# Write a program to convert and print this distance in feet, meter, inch and centimeter.

distance_km = float(input("Enter the distance between two cities in kilometers: "))

feet = 3280 
meter = 1000  
inch = 39370.1  
centimeter = 100000  

print("\n------------------------------------------------- \n")
print("Distance in feet:", distance_km * feet)
print("Distance in meters:", distance_km * meter)
print("Distance in inches:", distance_km * inch)
print("Distance in centimeters:", distance_km * centimeter)

 
---------------------------------------------------------------
