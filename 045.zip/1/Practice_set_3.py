# 1. Get basic Salary from the employee and display the net salary by calculating the following condition:
	# Applicble TA 4%, DA 30%,HRA 15% on basic salary.Applicble 3% tax,12% pf on basic salary.

basic_salary = int(input('Enter Basic Salary : '))
print('Basic Salary :',basic_salary)
ta = (basic_salary *4)/100
print('TA :',ta)
da = (basic_salary *30)/100
print('DA :',da)
hra = (basic_salary *15)/100
print('HRA :',hra)



print('________________________')

gs = basic_salary+ta+da+hra
print('Gross Salary : ',gs)

tax = (gs *3)/100
print('Tax :',tax)
pf = (gs *12)/100
print('PF :',pf)

print('________________________')

net = gs-tax-pf
print('Net Salary : ',net)
---------------------------------------------------------------

# 2. Get the marks of 5 subject at the command line and display the total of marks, and percentage.

import sys


sub1 = int(sys.argv[1])
sub2 = int(sys.argv[2])
sub3 = int(sys.argv[3])
sub4 = int(sys.argv[4])
sub5 = int(sys.argv[5])

print('Subject1 Mark',sub1)
print('Subject2 Mark',sub2)
print('Subject3 Mark',sub3)
print('Subject4 Mark',sub4)
print('Subject5 Mark',sub5)


print('________________________')

total = sub1+sub2+sub3+sub4+sub5
print('Total : ',total)

per = total / 5
print('Percentage :',per)

---------------------------------------------------------------

# 3. rojkot corporation wants to make simple application to calculate water bill of rajkotians.
# water is biging delivered by the corporation on per liter charge of below:
# upto 90 liters - rs. 0/ltr
# upto 150 liters -rs. 2/ltr
# upto 250 lirers -rs. 5/ltr
# more than 250 - rs. 10/ltr
# Accept unit consumption from consumer and disply the bill amount.

li = int(input('Enter Liter Value: '))

if li>0 and li<=90:
 	print('You have Not Pay Charges..')
  
elif li>90 and li<=150:
 	li = li * 2
	print('Your Charges Is : ',li)
  
elif li>150 and li<=250:
 	li = li * 5
 	print('Your Charges Is : ',li)
  
elif li>250:
 	li = li * 10
 	print('Your Charges Is : ',li)



---------------------------------------------------------------

# 4)

marks = float(input("Enter the marks scored by the student: "))

if marks > 90:
    print("A1 Grade")
elif marks <= 90 and marks > 80:
    print("A Grade")
elif marks <= 80 and marks > 70:
    print("B1 Grade")
    
elif marks <= 70 and marks > 60:
    print("B Grade")
    
elif marks <= 60 and marks > 50:
    print("Can do Better!")
else:
    print("Need to work hard.")



--------------------------------------------------------------

# 5)
yearly_income = float(input("Enter the yearly income earned by the taxpayer (in lakhs): "))


if yearly_income <= 8:
    tax = 0
    print("Tax to be paid: ₹", tax, " lakhs")

elif yearly_income > 8 and yearly_income <= 10:
    tax = 0.15 * yearly_income
    print("Tax to be paid: ₹", tax, " lakhs")
    
elif yearly_income > 10 and yearly_income <= 20:
    tax = 0.20 * yearly_income
    print("Tax to be paid: ₹", tax, " lakhs")
    
else:
    tax = 0.30 * yearly_income
    print("Tax to be paid: ₹", tax, " lakhs")


---------------------------------------------------------------
#6) Accept two integer values in separate variable, display the small value and big value out of it.

# Accept two integer values from the user
num1 = int(input("Enter the first integer value: "))
num2 = int(input("Enter the second integer value: "))

if num1 < num2:
    print("Smaller value:", num1)
    print("Larger value:", num2)
elif num1 > num2:
    print("Smaller value:", num2)
    print("Larger value:", num1)
else:
    print("Both values are equal:", num1)

---------------------------------------------------------------

# 7)

marks1 = float(input("Enter marks for student 1: "))
marks2 = float(input("Enter marks for student 2: "))
marks3 = float(input("Enter marks for student 3: "))
marks4 = float(input("Enter marks for student 4: "))


if marks1 >= marks2 and marks1 >= marks3 and marks1 >= marks4:
    print("student  1 is the highest scorer with", marks1, "marks.")
elif marks2 >= marks1 and marks2 >= marks3 and marks2 >= marks4:
    print("student  2 is the highest scorer with", marks2, "marks.")
elif marks3 >= marks1 and marks3 >= marks2 and marks3 >= marks4:
    print("student  3 is the highest scorer with", marks3, "marks.")
else:
    print("student  4 is the highest scorer with", marks4, "marks.")

 
---------------------------------------------------------------

# 8) An online selling app wants to develop a application to calculate shipping charges on the
# purchase. Accept amount from the user and calculate the shipping charges.
# The shipping charges are as below:
# Shopping amount less than 1500 – The shipping charges is Rs. 100/-
# --Type the message: Please purchase (1500-amount) to avail shipping charge of Rs. 80/-
# --Please pay (amount+100)
# Shopping amount more than 1500 and less than 3000 – The shipping charges is Rs. 70/-
# --Type the message: Please purchase (3000-amount) to avail shipping charge of Rs. 50/-
# --Please pay (amount+70)
# Shopping amount more than 3000 – Free shipping + 7% discount on amount
# --Type a message: You saved (amount*7/100)
# --Please pay (amount – discount)

amount = float(input("Enter the shopping amount: "))

if amount < 1500:
    shipping_charge = 100
    print(f"Please purchase ",1500 - amount," more to avail shipping charge of Rs. 80/-")
    total_amount = amount + shipping_charge
elif amount < 3000:
    shipping_charge = 70
    print(f"Please purchase ",3000 - amount," more to avail shipping charge of Rs. 50/-")
    total_amount = amount + shipping_charge
else:
    shipping_charge = 0
    discount = amount * .07
    print(f"You saved Rs. ",discount)
    total_amount = amount - discount

print(f"Shipping charge: Rs." ,shipping_charge)
print(f"Total amount to pay: Rs.", total_amount)

