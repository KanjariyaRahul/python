print("hello world")
print("this is the \n new line")

#concatenate the two strings
print("the city is " + "jamnagar")

#print optput on the sam line
print("Atmiya ",end='')
print("University")

#print variable list statements
a,b = 10,20
#sep separator between the arguments to print()
print(a,b,sep=",")

#the print (object statements)
a= ['a','atmiya','university','rajkot',True,10.25]
print(a)

#the print (string  variable list statements)
a=10
print(a, "the value is printed here")
print("user has entered",a ,"as an input")

#print formatted string statements
a=10
print("value is = %i" %a)

name ="rahul"
print("name is = %s" %name)
#20 spaces in the name
print("name is = %20s" %name)

#to print more than one ineger value

a,b = 10,20
print("A is = %i , B is = %i" %(a,b))

#we can use %f to display

#we can use %c to display a singal character

a = "Rahul"
print("the first character is : %c" %(a[0]))


