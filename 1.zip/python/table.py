
num = int(input("Enter Number Which Number's Table You Want :-"))
for i in range(1, 11):
   print(num,"*",i,"=",num*i)
   
while True:
    another = input("Do You Want To Print Another Table If Yes Write Yes  And No For No :-")
    if  another.upper() == "YES":
        num = int(input("Enter Number Which Number's Table You Want :-"))
        for i in range(1, 11):
         print(num,"*",i,"=",num*i)
         
    elif another.upper() == "NO":
        print("Exits...")
        exit()
            